# Online-voting-system
This online voting system is designed to allow voters to cast their ballots from any location with  internet access, removing the geographical barriers that often prevent people from voting. 
